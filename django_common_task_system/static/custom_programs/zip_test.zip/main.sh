
echo "Hello Shell"

python python_test.py